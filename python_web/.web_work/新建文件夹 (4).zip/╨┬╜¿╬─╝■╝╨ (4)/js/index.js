var mySwiper = new Swiper('.swiper-container', {
    autoplay: {
        delay: 3000,//设置轮播间隙时间
        stopOnLastSlide: false,//设置true 就是一次轮播,后面停止 如果是false则是一次轮播之后再轮播
        disableOnInteraction: false,//设置true的时候，我们操作了图片之后就不会再进行自动轮播了，如果是false 操作图片之后，图片会重新进行轮播
    },
    pagination: {
        el: '.swiper-pagination',
        clickable :true,
    },
navigation: {
nextEl: '.swiper-button-next',
prevEl: '.swiper-button-prev',
},
})

$('#tab>li').mouseenter(function(){
    $(this).addClass('active').siblings('li').removeClass('active')
    var a = $(this).index();
    console.log(a)
    $('#imgs>li').eq(a).addClass('selected').siblings('li').removeClass('selected')
})


